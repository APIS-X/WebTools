# 概述


Web Office SDK for Javascript 是在线Office文档编辑面向网页开发者提供的网页开发工具包， 后续的文档将简称`js-sdk`。通过使用 `js-sdk`，网页开发者可以为自定义界面显示、页面状态、监听事件等能力，同时可以直接使用高级 API 来操作文档，为用户提供更优质的网页体验。

赶紧前往 [快速开始篇](./base/quick-start.md) 开始使用`js-sdk`吧