# 目录

## 控制目录显示与否

> 最低支持版本 v1.1.3

```javascript
  /*
  * @param: bool
  * true 为显示， false 为隐藏
  */

  // 隐藏目录
  demo.WordApplication().ActiveDocument.ActiveWindow.DocumentMap = false
```
