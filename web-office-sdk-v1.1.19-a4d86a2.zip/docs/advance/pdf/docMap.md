# 目录相关功能


## 控制目录的显示隐藏

```javascript
  /*
  * true：显示目录
  * false：隐藏目录
  */
  // 显示目录
  demo.PDFApplication().ActivePDF.DocumentMap = true
```
