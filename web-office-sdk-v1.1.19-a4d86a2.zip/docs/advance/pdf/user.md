# 用户相关功能

## 获取当前登录操作者信息

```javascript
  /*
  * @return: object
  */
  let operatorsInfo = await demo.PDFApplication().ActivePDF.GetOperatorsInfo()
```
