# 设置页面渲染模式

> 最低支持版本 v1.1.2

```javascript
  /*
  * 1：单页模式
  * 0：多页模式
  */
  // 设置为单页模式
  demo.PDFApplication().ActivePDF.PageMode = 1
```
