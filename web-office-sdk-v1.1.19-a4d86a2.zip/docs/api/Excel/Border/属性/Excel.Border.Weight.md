# Border.Weight 属性
            
---

## 语法

### 表达式.Weight

表达式一个代表`Border`对象的变量。

## 示例

本示例对Sheet1上椭圆一的边框粗细进行设置。

```javascript
Worksheets.Item("Sheet1").Ovals(1).Border.Weight = xlMedium
```
