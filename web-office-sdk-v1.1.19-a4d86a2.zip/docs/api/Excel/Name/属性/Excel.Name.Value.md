# Name.Value 属性
            
---

## 语法

### 表达式.Value

表达式一个代表`Name`对象的变量。
