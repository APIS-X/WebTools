# Borders.Weight 属性
            
---

## 语法

### 表达式.Weight

表达式一个代表`Borders`对象的变量。
