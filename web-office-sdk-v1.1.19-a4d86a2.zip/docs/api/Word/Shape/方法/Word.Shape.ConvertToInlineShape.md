# Shape.ConvertToInlineShape 方法
            
---

## 语法

### 表达式.ConvertToInlineShape

表达式必选。一个代表`Shape`对象的变量。

## 说明

支持附加文字的图形不能转换为嵌入式图形。对这样的图形请使用### ConvertToFrame方法。

如果对包含多个图形的### ShapeRange对象使用此方法，将导致出错。
