# Shape.IncrementTop 方法
            
---

## 语法

### 表达式.IncrementTop(Increment)

表达式必选。一个代表`Shape`对象的变量。

## 参数

|名称|必选/可选|数据类型|说明|
|-|-|-|-|
|Increment|必选|Single|指定对象的垂直移动距离，以磅为单位。为正值时将形状下移；为负值时将形状上移。|
