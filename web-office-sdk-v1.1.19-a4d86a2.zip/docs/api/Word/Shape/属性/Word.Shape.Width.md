# Shape.Width 属性
            
---

## 语法

### 表达式.Width

表达式一个代表`Shape`对象的变量。
