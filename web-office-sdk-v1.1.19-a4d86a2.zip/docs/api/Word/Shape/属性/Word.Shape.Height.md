# Shape.Height 属性
            
---

## 语法

### 表达式.Height

表达式一个代表`Shape`对象的变量。
