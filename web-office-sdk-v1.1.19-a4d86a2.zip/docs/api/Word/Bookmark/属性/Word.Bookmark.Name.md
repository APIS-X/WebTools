# Bookmark.Name 属性
            
---

## 语法

### 表达式.Name

表达式必选。一个代表`Bookmark`对象的变量。
