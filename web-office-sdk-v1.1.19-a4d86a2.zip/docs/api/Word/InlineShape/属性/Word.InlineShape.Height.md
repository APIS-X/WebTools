# InlineShape.Height 属性
            
---

## 语法

### 表达式.Height

表达式一个代表`InlineShape`对象的表达式。
