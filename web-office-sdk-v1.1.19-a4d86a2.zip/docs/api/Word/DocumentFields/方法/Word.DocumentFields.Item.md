# DocumentFields.Item 方法
            
---

## 语法

### 表达式.Item(Index)

表达式一个代表`DocumentFields`对象的表达式。

## 参数

|名称|必选/可选|数据类型|说明|
|-|-|-|-|
|Index|必选|Variant|要获取的公文域索引值|
