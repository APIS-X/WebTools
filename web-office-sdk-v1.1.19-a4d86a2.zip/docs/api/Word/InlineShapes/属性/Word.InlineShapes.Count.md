# InlineShapes.Count 属性
            
---

## 语法

### 表达式.Count

表达式必选。一个代表`InlineShapes`集合的变量。
