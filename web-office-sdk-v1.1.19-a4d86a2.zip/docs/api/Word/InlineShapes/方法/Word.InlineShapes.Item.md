# InlineShapes.Item 方法
            
---

## 语法

### 表达式.Item(Index)

表达式必选。一个代表`InlineShapes`集合的变量。

## 参数

|名称|必选/可选|数据类型|说明|
|-|-|-|-|
|Index|必选|Long|要返回的单个对象。可以是代表单个对象序号位置的 Long 类型值。|

## 返回值InlineShape
