# ContentControls.Count 属性
            
---

## 语法

### 表达式.Count

表达式一个代表`ContentControls`对象的变量。
