# Table.Range 属性
            
---

## 语法

### 表达式.Range

表达式必选。一个代表`Table`对象的变量。
