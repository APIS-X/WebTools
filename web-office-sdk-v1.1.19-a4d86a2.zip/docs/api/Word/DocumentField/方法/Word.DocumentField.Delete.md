# DocumentField.Delete 方法
            
---

## 语法

### 表达式.Delete(DeleteWithContent,)

表达式一个代表`DocumentField`对象的表达式。

## 参数

|名称|必选/可选|数据类型|说明|
|-|-|-|-|
|DeleteWithContent|可选|Boolean|是否删除该域中的内容，默认为false|
