# DocumentField.Range 属性
            
---

## 语法

### 表达式.Range

表达式一个代表`DocumentField`对象的变量。
