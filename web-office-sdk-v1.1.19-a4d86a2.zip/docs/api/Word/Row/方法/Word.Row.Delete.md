# Row.Delete 方法
            
---

## 语法

### 表达式.Delete

表达式必选。一个代表`Row`对象的变量。
