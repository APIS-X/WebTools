# ContentControl.PlaceholderText 属性
            
---

## 语法

### 表达式.PlaceholderText

表达式一个返回`ContentControl`对象的表达式。

## 说明

可以使用### SetPlaceholderText方法设置内容控件的占位符文本。
