# View.Zoom 属性
            
---

## 语法

### 表达式.Zoom

表达式一个代表`View`对象的变量。

## 示例

以下示例将第一个文档窗口的视图缩小为30%。

```javascript
Windows.Item(1).View.Zoom = 30
```
