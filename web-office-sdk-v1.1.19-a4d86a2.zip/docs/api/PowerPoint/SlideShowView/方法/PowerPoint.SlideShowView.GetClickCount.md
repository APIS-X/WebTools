# SlideShowView.GetClickCount 方法
            
---

## 语法

### 表达式.GetClickCount

表达式一个代表`SlideShowView`对象的变量。

## 返回值Long

## 说明

如果幻灯片包含动画，则### GetClickCount方法返回用户换到下一张幻灯片之前所需的鼠标单击次数。
