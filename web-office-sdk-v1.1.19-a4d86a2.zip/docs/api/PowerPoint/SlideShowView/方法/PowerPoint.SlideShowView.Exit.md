# SlideShowView.Exit 方法
            
---

## 语法

### 表达式.Exit

表达式一个代表`SlideShowView`对象的变量。

## 示例以下示例将结束第一个幻灯片放映窗口中的幻灯片放映。

```javascript
SlideShowWindows.Item(1).View.Exit()
```
