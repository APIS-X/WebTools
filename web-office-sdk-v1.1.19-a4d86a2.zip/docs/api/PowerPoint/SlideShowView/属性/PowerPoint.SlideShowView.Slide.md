# SlideShowView.Slide 属性
            
---

## 语法

### 表达式.Slide

表达式一个代表`SlideShowView`对象的变量。

## 说明

如果当前显示的幻灯片来源于一个嵌入演示文稿，则可以使用`Slide`对象（从`Slide`属性返回）的`Parent`属性返回包含该幻灯片的嵌入演示文稿。（`SlideShowWindow`对象或`DocumentWindow`对象的`Presentation`属性返回创建该窗口的演示文稿，而不是该嵌入演示文稿。）
